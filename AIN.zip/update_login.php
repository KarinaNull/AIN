<?php
session_start();
// Проверка на авторизацию
if (!isset($_SESSION['username'])) {
    header("Location: auth.php");
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newLogin = $_POST['new_login'];
    $username = $_SESSION['username'];

    // Получаем текущий логин пользователя из сессии
    $currentLogin = $_SESSION['login'];

    // Если новый логин тот же, что и текущий, то возвращаем сообщение
    if ($newLogin === $currentLogin) {
        $_SESSION['message'] = "Вы уже используете этот логин!";
        header("Location: acount.php");
        exit();
    }

    // Проверка на уникальность нового логина
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE login = ?");
    $stmt->bind_param("s", $newLogin);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();


    // Получаем данные пользователя по его логину
    $stmt = $conn->prepare("SELECT id FROM users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();





    if ($count > 0) {
        $_SESSION['message'] = "Этот логин уже занят!";
        header("Location: acount.php");
        exit();
    } else {
        // Обновление логина в базе данных
        $stmt = $conn->prepare("UPDATE users SET login = ? WHERE username = ?");
        $stmt->bind_param("ss", $newLogin, $username);
        $stmt->execute();
        $stmt->close();

        // Обновляем логин в сессии
        $_SESSION['login'] = $newLogin;
        $_SESSION['message'] = "Логин успешно обновлен!";

        header("Location: acount.php"); // Переадресация на страницу учетной записи
        exit();
    }
}
